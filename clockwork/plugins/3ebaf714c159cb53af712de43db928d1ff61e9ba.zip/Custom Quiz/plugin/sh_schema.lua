local PLUGIN = PLUGIN;

Clockwork.quiz:SetEnabled(true/false); -- Be sure to select one! It can't be TRUE and FALSE. Recommended: TRUE.
Clockwork.quiz:AddQuestion("", 1, "", ""); --The first set of quote marks is where your question goes.
Clockwork.quiz:AddQuestion("", 1, "", ""); --The number, which can be 1 or 2, determines what answer is the right one.
Clockwork.quiz:AddQuestion("", 1, "", ""); -- number 1 means the third set of quote marks is correct, 2 means the last set of
Clockwork.quiz:AddQuestion("", 1, "", ""); -- quote marks is correct. You can have more than one answer but only 1 is correct.
Clockwork.quiz:AddQuestion("", 1, "", ""); --The third set of quote marks is your first answer.
Clockwork.quiz:AddQuestion("", 1, "", ""); --The last set of quote marks is your second answer.
Clockwork.quiz:AddQuestion("", 1, "", ""); --The correct answer is determined by what number is set.
--								  1    2