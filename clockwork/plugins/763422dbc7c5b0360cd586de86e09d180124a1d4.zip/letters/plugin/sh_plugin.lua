local PLUGIN = PLUGIN;

letters = {};
text = {};

Clockwork.kernel:IncludePrefixed("sv_hooks.lua");