local Clockwork = Clockwork;
Clockwork.config:AddToSystem("Lock Characters", "lock_characters", "Enable this to lock all players in their current characters to avoid charswapping during sweeps.");